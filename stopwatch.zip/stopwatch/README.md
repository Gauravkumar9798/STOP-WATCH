# STOPWATCH

A Pen created on CodePen.io. Original URL: [https://codepen.io/GAURAV-RIDER/pen/vYqOLgR](https://codepen.io/GAURAV-RIDER/pen/vYqOLgR).

